package mk.ukim.finki.wp.lab.service.impl;


import lombok.AllArgsConstructor;
import mk.ukim.finki.wp.lab.model.EventBooking;
import mk.ukim.finki.wp.lab.repository.EventBookingRepository;
import mk.ukim.finki.wp.lab.service.EventBookingService;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class EventBookingServiceImpl implements EventBookingService {
    private final EventBookingRepository eventBookingRepository;
    @Override
    public EventBooking placeBooking(String eventName, String attendeeName, String attendeeAddress, int numberOfTickets){
        EventBooking eventBooking = new EventBooking(eventName,attendeeName,attendeeAddress,(long)numberOfTickets);
        eventBookingRepository.saveEventBooking(eventBooking);
        return eventBooking;
    }

}
