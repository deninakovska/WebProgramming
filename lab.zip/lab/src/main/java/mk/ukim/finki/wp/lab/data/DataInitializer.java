package mk.ukim.finki.wp.lab.data;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import mk.ukim.finki.wp.lab.model.Location;
import mk.ukim.finki.wp.lab.repository.EventRepository;
import mk.ukim.finki.wp.lab.repository.LocationRepository;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class DataInitializer {

    private final LocationRepository locationRepository;
    @PostConstruct
    public void initializeData(){
        for(int i = 0;i<2;i++){
            Location location = new Location("name"+i,"address"+i,"capacity"+i,"description"+i);
            locationRepository.save(location);
        }

    }

}
