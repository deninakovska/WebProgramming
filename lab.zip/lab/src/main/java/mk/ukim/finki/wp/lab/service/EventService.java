package mk.ukim.finki.wp.lab.service;

import mk.ukim.finki.wp.lab.model.Event;
import mk.ukim.finki.wp.lab.model.Location;

import java.util.List;
import java.util.Optional;

public interface EventService {
    List<Event> listAll();
//    List<Event> searchEventsByText(String text);
//    List<Event> searchEventsByRating(Double rating);
//    List<Event> searchEventsByTextAndRating(String text, Double rating);
    void addEvent(String name, String description, double popularityScore, Long locationId);
    void editEvent(Long eventId, String name, String description, double popularityScore, Long locationId);
    void deleteEvent(Long eventId);
    Event findEventById(Long eventId);
    List<Event>findAllByLocationId(Long locationId);
    Optional<Location> findLocation(Long Id);
}
