package mk.ukim.finki.wp.lab.repository;

import mk.ukim.finki.wp.lab.model.EventBooking;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class EventBookingRepository {
    List<EventBooking> eventBookingList = new ArrayList<>();
    public void saveEventBooking(EventBooking eventBooking){
        eventBookingList.add(eventBooking);
    }

}
