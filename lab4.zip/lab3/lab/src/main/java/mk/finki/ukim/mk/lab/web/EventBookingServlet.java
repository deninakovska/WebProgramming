package mk.finki.ukim.mk.lab.web;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import mk.finki.ukim.mk.lab.service.EventBookingService;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.spring6.SpringTemplateEngine;
import org.thymeleaf.web.IWebExchange;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;

import java.io.IOException;

@WebServlet(name="event-booking-servlet", urlPatterns = "/eventBooking")
public class EventBookingServlet extends HttpServlet {

    private final EventBookingService eventBookingService;
    private final SpringTemplateEngine springTemplateEngine;
    public EventBookingServlet(SpringTemplateEngine springTemplateEngine, EventBookingService eventBookingService) {
        this.springTemplateEngine = springTemplateEngine;
        this.eventBookingService = eventBookingService;
    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        IWebExchange webExchange = JakartaServletWebApplication
                .buildApplication(getServletContext())
                .buildExchange(req, resp);

        WebContext context = new WebContext(webExchange);

        String ipAddress = req.getRemoteAddr();
        String attendeeName = req.getHeader("User-Agent");
        String eventName = req.getParameter("eventName");
        Integer numTickets = Integer.valueOf(req.getParameter("numTickets"));

        eventBookingService.placeBooking(ipAddress,attendeeName,eventName,numTickets);

        context.setVariable("ipAddress", ipAddress);
        context.setVariable("attendeeName", attendeeName);
        context.setVariable("eventName",eventName);
        context.setVariable("numTickets", numTickets);

        springTemplateEngine.process("bookingConfirmation.html",context, resp.getWriter());

    }
}

